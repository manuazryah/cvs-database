<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<style>
    .cv-error{
        background: white;
        padding: 10px;
        color: #0f74bb;
    }
    .cv-error h4{
        font-weight: 600;
        font-size: 22px;
    }
</style>
<div class="cv-error">
    <h4>Job Seeker Details Not Available</h4>
</div>


<?php

echo $searchTerm = $_GET['term'];
exit;
?>


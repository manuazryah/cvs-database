<?php

use common\components\SearchCvViewWidget;

?>
<?= SearchCvViewWidget::widget(['id' => $model->id]) ?>
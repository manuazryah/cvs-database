<?php

return [
    'home' => 'employer/home',
    'update-profile' => 'employer/update',
    'change-password' => 'employer/change-password',
    'user-packages' => 'employer/user-plans',
    'upgrade-package' => 'employer/upgrade-package',
    'shortlist-folder' => 'employer/shortlist-folder',
    'view-cv/<id:\d+>' => 'employer/view-cvs',
];

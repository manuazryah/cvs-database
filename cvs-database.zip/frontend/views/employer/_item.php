<?php

use common\components\CandidateViewWidget;

?>
<?= CandidateViewWidget::widget(['id' => $model->id]) ?>
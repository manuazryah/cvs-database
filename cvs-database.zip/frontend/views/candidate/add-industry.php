<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\Industry */

$this->title = 'Add Industry';
$this->params['breadcrumbs'][] = ['label' => 'Industries', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<main id="maincontent" class="my-account">
    <section class="manage">
        <div class="row">
            <div class="col-md-12">
                <?php $form = ActiveForm::begin(); ?>
                <?= $form->field($model, 'industry_name')->textInput(['maxlength' => true]) ?>
                <?= Html::submitButton('Submit', ['class' => 'btn btn-success mrg-top-btn', 'id' => 'add_industry']) ?>
                <?php ActiveForm::end(); ?>
            </div>
        </div>
    </section>
</main>
<style>
    #modalContent{
        display: inline-block;
        width: 100%;
    }
    #maincontent{
        padding: 0px;
    }
</style>
<script>

    $('#add_industry').click(function (event) {
        event.preventDefault();
        if (valid()) {
            var industry_name = $('#industry-industry_name').val();
            $.ajax({
                url: '<?= Yii::$app->homeUrl ?>candidate/add-industry',
                type: "post",
                data: {industry_name: industry_name},
                success: function (data) {
                    var $data = JSON.parse(data);
                    if ($data.con === "1") {
                        var newOption = $('<option value="' + $data.id + '">' + $data.name + '</option>');
                        $('#candidateprofile-industry').append(newOption);
                        $('#candidateprofile-industry' + ' option[value=' + $data.id + ']').attr("selected", "selected");
                        var vals = $('#candidateprofile-industry').val();
                        $('#candidateprofile-industry').select2('val', vals);
                        $('#modal').modal('hide');
                    } else {
                        alert($data.error);
                    }

                }, error: function () {

                }
            });
        } else {
//            alert('Please fill the Field');
        }

    });
    var valid = function () { //Validation Function - Sample, just checks for empty fields
        var valid;
        $("input").each(function () {
            if (!$('#industry-industry_name').val()) {
                $('#industry-industry_name').focus();
                valid = false;
            }
        });
        if (valid !== false) {
            return true;
        } else {
            return false;
        }
    }
</script>
